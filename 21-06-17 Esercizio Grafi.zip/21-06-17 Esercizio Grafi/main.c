#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "Graph.h"
Graph createGraph(int nodes);
Graph modifica(Graph G);
Graph esercizio(Graph G, Graph H);
int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));
    
    int scelta,scelta_2,numero_nodi;
    Graph G=NULL,H=NULL,T=NULL;
    do{
    printf("\n\n");
    printf("1.Grafo random\n");
    printf("2.Grafo manuale\n");
    printf("Scelta: ");
    scanf("%d",&scelta);
    }while(scelta!=1 && scelta!=2);
    
    printf("\nNodi grafo G:");
    scanf("%d",&numero_nodi);
    if(scelta==1){
      G = randomGraph(numero_nodi, 5, 25);
      H = randomGraph(2*numero_nodi, 5, 25); }
    else {
        printf("\nCREA MANUALMENTE GRAFO G\n");
	G = createGraph(numero_nodi);
        printf("\nCREA MANUALMENTE GRAFO G\n");
        H = createGraph(2*numero_nodi);
                           
         }
     
   


    do{ CLEARSCREEN;
    T = esercizio(G,H);
    printf("\nGRAFO G\n");
    printGraph(G);
    printf("\nGRAFO H\n");
    printGraph(H);
    printf("\nGRAFO T\n");
    printGraph(T);
    printf("\n\nVuoi modificarli?\n"); //Stampa a video;
			    printf("1. Si.\n"); //Stampa a video;
			    printf("2. No.\n"); //Stampa a video;
			    printf("Scelta: "); //Stampa a video;
                            scanf("%d",&scelta);
         if(scelta==1){
             printf("\n\nVuoi modificare G o H?\n");
             printf("1. G.\n"); //Stampa a vide
             printf("2. H.\n"); //Stampa a video;
	     printf("Scelta: "); //Stampa a video;
             scanf("%d",&scelta_2);   
               if(scelta_2==1)
                  G=modifica(G);
               else
                H=modifica(H); 
             }
    }while(scelta!=2);
return 0;
}

Graph createGraph(int nodes) {
    Graph G = initGraph(nodes);
    int scelta;
    int target;
    int peso;
    
    for (int i = 0; i < nodes; i++) {
        printf("INSERIRE ADIACENTI DI %d\n",i); //Stampa a video;
       		do{ //Inizio inserimento adiacenti;
                            printf("\n\n");
			    printf("Vuoi inserire un nodo adiacente a %d? \n",i); //Stampa a video;
			    printf("1. Si.\n"); //Stampa a video;
			    printf("2. No.\n"); //Stampa a video;
			    printf("Scelta: "); //Stampa a video;
                            scanf("%d",&scelta);
                            if(scelta==1){ //Se scegliamo di inserire...
                               printf("\nInserire nuovo nodo adiacente: ");  //Stampa a video;
                               scanf("%d",&target);
                               printf("\nInserire peso: ");
			       scanf("%d",&peso);
                               addEdge(G,i,target,peso); }
             } while(scelta==1); CLEARSCREEN; //Inizio inserimento adiacenti; 
  }
    CLEARSCREEN; //Pulizia schermo;
    return G;
}


Graph esercizio(Graph G, Graph H){
	Graph T = initGraph(H->nodes_count);
        Graph K=NULL,F=NULL;
	List g,h;
	int i,j,peso,flag;
	int *aux1 = (int*)calloc(H->nodes_count,sizeof(int));
	int *aux2 = (int*)calloc(H->nodes_count,sizeof(int));
        if(G->nodes_count>=H->nodes_count) {
           K=G;
           F=H;         }
        else {   K=H;
                 F=G;}

	for(i = 0; i < K->nodes_count; ++i){
		flag = 0;
		if(i < F->nodes_count){
			g = F->adj[i];
			flag = 1;
		}
		h = K->adj[i];
		while(h){
			aux1[h->target] = h->peso;
			aux2[h->target] = 1;
			h = h->next;
		}
		while(g && flag){
			if(aux2[g->target] == 1){
				
				peso = aux1[g->target] > g->peso ? aux1[g->target] : g->peso;
				addEdge(T,i,g->target,peso);
				aux2[g->target] = 0;
			}
			
			g = g->next;
		}
		
		}
	
	return T;
}




Graph modifica(Graph G){
int scelta,target,peso,sorgente;

	printf("\n\n\nCosa vuoi modificare?\n");
	printf("1.Aggiungi arco\n");
	printf("2.Rimuovi arco\n");
	scanf("%d",&scelta);

     if(scelta==1){
       printf("\nSorgente: "); scanf("%d",&sorgente);
       printf("\nInserire nuovo nodo adiacente a %d: ",sorgente);  //Stampa a video;
              scanf("%d",&target);
              printf("\nInserire peso: ");
              scanf("%d",&peso);
              addEdge(G,sorgente,target,peso); }
    else {  printf("\nSorgente: "); scanf("%d",&sorgente);
            printf("\nTarget: ");   scanf("%d",&target);
            removeEdge(G,sorgente,target);  }
    return G;

}   
