#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "Tree.h"
//Struttura albero con tre nodi.

void check_abr(Tree T,int *check);


int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));
    
    
    Tree T1 = NULL;  //Creo T1;
    Tree T2 = NULL;  //Creo T2;
    
    int val,i;
    printf("\nCREA ALBERO 1: \n");
    for(i=0;i<5;i++){ //Creo e leggo 5 elementi
	printf("Valore %d: ",i);
	scanf("%d",&val);
	T1=insertNodeTree(T1,val); //Inserisco l'elemento i-esimo nell'ABR.
	printf("\n"); }
    printf("\nCREA ALBERO 1: \n");
    for(i=0;i<5;i++){ //Creo e leggo 5 elementi
	printf("Valore %d: ",i);
	scanf("%d",&val);
	T2=insertNodeTree(T2,val); //Inserisco l'elemento i-esimo nell'ABR.
	printf("\n"); }
    
    


    inOrder(T1); //Stampo T1;
    printf("\n"); 
    inOrder(T2);  //Stampo T2;
    printf("\n");
   
    
   
    return 0;
}

/*Questa funzione si occupa di sommare i valori agli stessi livelli(se esistono) di T1 e T2 nell'albero ternario T. Prende in input i due alberi binari e un albero ternario.
In output ritorna la radice del nuovo albero ternario.*/
Tree stessaStruttura(Tree T1,Tree T2,Tree_Tern T) {
    if (T1 != NULL && T2!=NULL) { //Se T1 e T2 sono pieni...
	   T=insertNodeTree_Tern(T,T1->info+T2->info);  //Copia T1+T2 in T.
           T=estensione(T1->sx,T2->sx,T); //Scendi a sinistra sia T1,T2,T
           T=estensione(T1->dx,T2->dx,T); }  //Scendi a destra sia T1,T2,T
    else if(T1!=NULL && T2==NULL){ //Se T1 pieno e T2 vuoto
	   T=insertNodeTree_Tern(T,T1->info); //Copia in T solo T1.
	   T=estensione(T1->sx,T2,T); //Scendi a sinistra solo T1 e T.
	   T=estensione(T1->dx,T2,T); }  //Scendi a destra  solo T1 e T.
   else if(T1==NULL && T2!=NULL){ //Se T1 vuoto e T2 pieno
	   T=insertNodeTree_Tern(T,T2->info); //Copia in T solo T2.
	   T=estensione(T1,T2->sx,T); //Scendi a sinistra solo T2 e T.
	   T=estensione(T1,T2->dx,T); }  //Scendi a destra solo T2 e T.
        
       
       
return T; //Return T.
          }
        
    
void check_abr(Tree T,int *check){
    if(T!=NULL) {
      if(T->sx!=NULL && T->dx!=NULL) {
        if(T->info<T->sx->info || T->info>=T->dx->info)
           (*check)=1;
           }
      else if(T->sx!=NULL && T->dx==NULL) {
             if(T->info<T->sx->info)
                (*check)=1;
                }
      else if(T->sx==NULL && T->dx!=NULL) {
             if(T->info>=T->dx->info)
                (*check)=1;
                }

       check_abr(T->sx,check);
       check_abr(T->dx,check);    

}  

}




