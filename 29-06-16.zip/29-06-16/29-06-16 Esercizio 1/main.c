#include <stdio.h>
#include "stack.h"
void gioco_ric(Stack S1,Stack S2,Stack temp,int turno_S1,int turno_S2,int *err); //Procedura del gioco (esercizio)
void eliminaElem(Stack S1,Stack S2,int i,int partenza,int valore, int *err); //Procedura elimina elemeno da S1.
int sommaStack(Stack S1,Stack S2,int i,int partenza,int somma,int valore,int *err); //Somma dei primi "i" elementi dello stack.
int punteggioStack(Stack S1,int punteggio,int *err); //Calcolo del punteggio finale.
void gioco(Stack S1,Stack S2); //Funzione del gioco (esercizio).
int main(int argc, const char * argv[]) {
    int err = 0;
    Stack S1 = initStack();  //Inizializza S1;
    randomStack(S1, 5, &err);  //Riempi Stack random.
    Stack S2 = initStack(); //Inizializza S2;
    randomStack(S2, 7, &err); //Riempi Stack random.
    printStack(S1, &err); //Stampa S1;
    printf("\n");
    printStack(S2,&err); //Stampa S2;
    printf("\n");
    
    gioco(S1,S2); //Esercizio
    
    
    

    return 0;
}

/*Questa funzione prende in input S1 e uno stack temporaneo S2. Inoltre il valore di "i" serve ad indicare quanti elementi dobbiamo sommare partendo da un valore di "partenza". La funzione estrae il primo elemento dello stack,se stiamo ancora tra i primi "i" elementi allora lo somma alla variabile "somma",successivamente in ogni caso inseriamo questo elemento in S2 e richiamiamo la funzione. Una volta che S1 è tutto vuoto avremo in S2 una copia inversa di S1 che andremo a riversare di nuovo in S1. Ritorna la somma dei primi "i" elementi dello stack.*/
int sommaStack(Stack S1,Stack S2,int i,int partenza,int somma,int valore,int *err){
	if(emptyStack(S1)==1){  //S1 è vuoto...
          reverseStack(S2,S1,err); //Riversa S2 in S1..
	  return somma; } //..e ritorna la somma
	else {  //S1 ha ancora elementi...
               valore=pop(S1,err); //...estrai in testa
               if(partenza<=i) //...siamo nel range i-partenza...
                  somma=somma+valore; //...allora somma
                push(S2,valore,err); //...rimettilo in testa ad S2
                somma=sommaStack(S1,S2,i,partenza+1,somma,valore,err); //richiama la funzione
         
}	

}	

/*Questa procedura prende in input S1 e uno stack temporaneo S2. Inoltre il valore di "i" serve ad indicare di quanti elementi dobbiamo scorrere partendo da un valore di "partenza". La funzione estrae il primo elemento dello stack,se non è l'elemento alla posizione che vogliamo eliminare lo reinseriamo in S2,altrimenti non lo reinseriamo. Successivamente richiamiamo ricorsivamente la procedura. Una volta che S1 è tutto vuoto avremo in S2 una copia inversa di S1 ma senza il valore alla posizione "i" che andremo a riversare di nuovo in S1. */
void eliminaElem(Stack S1,Stack S2,int i,int partenza,int valore, int *err){
   if(emptyStack(S1)==1) //S1 è vuoto...
          reverseStack(S2,S1,err); //Riversa S2 in S1.
	  
	else {
               valore=pop(S1,err); //...estrai da S1.
               if(partenza!=i) //...se non è l'elemento "i-esimo"
                  push(S2,valore,err); //...reinseriscilo in S2
                
  eliminaElem(S1,S2,i,partenza+1,valore,err); //Richiama la procedura.
        
}	

}

/*Questa procedura ci è utile per calcolare il punteggio dello stack in base a quanti elementi sono rimasti in esso.*/
int punteggioStack(Stack S1,int punteggio,int *err){
	if(emptyStack(S1)==1) //Stack vuoto...
          return punteggio;  //...ritorna punteggio.
	else {
               pop(S1,err); //togli elementi
               punteggio=punteggioStack(S1,punteggio+1,err); //incrementa punteggio e richiama funzione.
               
        
}	

}	


/*Questa procedura contiene tutte le utility per richiamare la vera procedura che eseguirà il gioco sugli Stack*/
void gioco(Stack S1,Stack S2){
        int err = 0;
        int punteggio_S1,punteggio_S2; //variabili che conterranno i punteggi.
	Stack temp = initStack(); //inizializza stack temporaneo utilizzato per l'eliminazione e la somma.
        gioco_ric(S1,S2,temp,0,0,&err); //funzione che si occupa di eseguire il gioco.
        printf("\n");
	printStack(S1, &err); //stampa nuovo S1.
        printf("\n");
        printStack(S2,&err); //stampa nuovo S2.
        printf("\n");  
	punteggio_S1=punteggioStack(S1,0,&err); //Calcola punteggio S1.
	punteggio_S2=punteggioStack(S2,0,&err); //Calcola punteggio S2.
        if(punteggio_S1>punteggio_S2) //Stampa punteggi e vincitore.
	 printf("\n %d - %d Vince S1",punteggio_S1,punteggio_S2);
        else if(punteggio_S1<punteggio_S2)
	 printf("\n %d - %d Vince S2",punteggio_S1,punteggio_S2);
        else
 	 printf("\n %d - %d Pareggio",punteggio_S1,punteggio_S2);

printf("\n");



}






/*Questa procedura si occupa di eseguire il vero gioco richiesto nell'esercizio. Prende in input i due stack più uno temporaneo.
Per i primi due stack avremo delle variabili che indicheranno il turno cioè fino a quale posizione bisogna sommare che verranno incrementati di +1 ad ogni passaggio. Questa due variabili cammineranno di pari passo finchè uno dei due stack non arriva all'ultimo elemento,in questo caso per quello stack il turno sarà ripetuto fino alla fine del gioco. Il gioco termina se almeno uno dei due stack è vuoto oppure se entrambi gli stack sono giunti a sommare fino al loro ultimo elemento.*/
void gioco_ric(Stack S1,Stack S2,Stack temp,int turno_S1,int turno_S2,int *err){
if(emptyStack(S1)!=1 && emptyStack(S2)!=1 && (turno_S1!=S1->A[0] || turno_S2!=S2->A[0])) { //Condizione per giocare...
  if(sommaStack(S1,temp,turno_S1,0,0,0,err) <= sommaStack(S2,temp,turno_S2,0,0,0,err)){ //Se vince S2...
         eliminaElem(S1,temp,turno_S1,0,0,err); } //Elimina "i-esimo" da S1.
  else if(sommaStack(S1,temp,turno_S1,0,0,0,err) > sommaStack(S2,temp,turno_S2,0,0,0,err)) { //Se vince S1..
         eliminaElem(S2,temp,turno_S2,0,0,err); } //Elimina "i-esimo" da S2.

	if(turno_S1<S1->A[0]) //Se possiamo scorrere ancora S1...
          turno_S1=turno_S1+1; //incrementa il turno altrimenti sarà ripetuto lo stesso.
        if(turno_S2<S2->A[0]) //Se possiamo scorrere ancora S2..
          turno_S2=turno_S2+1;//incrementa il turno altrimenti sarà ripetuto lo stesso.

gioco_ric(S1,S2,temp,turno_S1,turno_S2,err); //Richiama il gioco al prossimo turno.
}

}
