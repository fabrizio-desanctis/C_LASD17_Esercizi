#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "Tree.h"
int minimo_abr(Tree T);  //Valore minimo in un abr.
int massimo_abr(Tree T); //Valore massimo in un abr,
int successivo_abr(Tree T,int info,int successivo); //Dato un ABR e un valore trova e ritorna il suo successivo. Ritorna se stesso se è il maggiore;
int esercizio(Tree T,Tree temp,int massimo,int risultato); //Funzione dell'esercizio;
int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));
    
    int val=0;
    Tree T=NULL;   //Dichiaro T.
    
    for(int i=0;i<5;i++){ //Creo e leggo 5 elementi
	printf("Valore %d: ",i);
	scanf("%d",&val);
	T=insertNodeTree(T,val); //Inserisco l'elemento i-esimo nell'ABR.
	printf("\n"); }
    
    // Eseguo una In Order sull'albero T
    inOrder(T); //Stampa albero
    printf("\n");

    
    Tree temp=T; //ABR temporaneo;
    int massimo=massimo_abr(temp); //Massimo di T.
    printf("\nIl massimo dell'ABR e' %d.\n",massimo); //Stampa del massimo.
    int risultato=esercizio(T,temp,massimo,1); //Variabile in cui sarà ritornato il risultato finale
    if(risultato==1) //Vera o falsa
     printf("\nRISULTATO: Ogni elemento (tranne il massimo) ha il suo successivo\n");
    else
     printf("\nRISULTATO: Non tutti gli elementi hanno il loro successivo\n");
    
   
    return 0;
}


//Questa funzione calcola il minimo valore di un abr.
int minimo_abr(Tree T){
 Tree temp=T;
	while(temp!=NULL && temp->sx!=NULL){
	  temp=temp->sx;}
return temp->info;
}

//Questa funzione calcola il valore massimo di un abr.
int massimo_abr(Tree T){
 Tree temp=T;
	while(temp!=NULL && temp->dx!=NULL){
	  temp=temp->dx;}
return temp->info;
}

//Funzione che calcola l'elemento successivo ad info nell'abr.
int successivo_abr(Tree T,int info,int successivo){
	if(T!=NULL){ //Se pieno... 
	  if(T->info<info) //Se T->info è minore del valore cercato..
	    successivo=successivo_abr(T->dx,info,successivo); //Cercalo a destra.
          else if(T->info==info){ //Se T->info è uguale al valore cercato...
                if(T->dx!=NULL){ //Se esiste sotto albero destro...
		successivo=minimo_abr(T->dx); //Cerca il successivo nel sotto-albero destro. Sarà il minimo.
		return successivo;} //Ritorna successivo;
                else return T->info; //Se non esiste sotto albero dx allora non esisterà successivo per il valore info.
                }
		 
	 else  { //Se T->info è maggiore del valore cercato..
		successivo=successivo_abr(T->sx,info,successivo); } //..cercalo nel sottoalbero sx.
                   }
          }


//Funzione richiesta dall'esercizio.
int esercizio(Tree T,Tree temp,int massimo,int risultato){
	if(T!=NULL){ //Se T è pieno..
		temp=T;//...salvalo temporanemanete.
	   if(successivo_abr(temp,T->info,-1) != (T->info)+1) //Se  non esiste T->info+1.. 
		if(T->info!=massimo){ //...verifica che non sia il massimo(il massimo è da escludere sempre)
                        risultato=0; //Allora ritorna falso.
			 }
		//Se invece esiste,scorri gli altri elementi dell'abr.
	   else{
	     risultato=esercizio(T->sx,temp,massimo,risultato) && esercizio(T->dx,temp,massimo,risultato);
             return risultato; }
   
}   return risultato;  //Finito l'albero significa che tutti gli elementi hanno successore e ritorna vero.

}







