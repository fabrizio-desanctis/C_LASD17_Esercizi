#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "list.h"
void swap(List L1,List L2);
List removeNodeRipetutiList(List L1,List L2);
List removeNodeList1toList2(List L1,List L2,List temp);
int main(){
        srand((unsigned int)time(NULL));
	int i=0;
        List L1=NULL,L2=NULL; //Dichiarazione delle due liste.
        
        //Ciclo che inserisce 5 (ma è possibile cambiare numero) elementi casuali in L1;
	for (i=0;i<7;i++)
		L1 = appendNodeList(L1,NULL,rand() % 25); //Appende nodo e ritorna nuova L1;
         
	 //Ciclo che inserisce 5 (ma è possibile cambiare numero) elementi casuali in L2;
        for(i=0;i<7;i++)
             L2 = appendNodeList(L2,NULL,rand() % 25); //Appende nodo e ritorna nuova L2;
             
        printList(L1);  //Stampa a video di L1;
        printf("\n");
        printList(L2);
        printf("\n\n");
      
        swap(L1,L2); //Passiamo le liste con la & per permetterne la modifica.
        printf("\n");
      
        freeList(L1);
        freeList(L2);
        
	return 0;
}

/*Procedura che contiene le routine per eliminare tutti i multpli di 2 da L1 ed inserli in testa a L2.
  Poi elimina da L2 tutti i multipli di 5 e li inserisce in testa ad L1. Praticamente il cuore dell'esercizio
  Prende in input i puntatori alle due liste.*/
void swap(List L1,List L2){
     List temp;
	L1=removeNodeRipetutiList(L1,temp); //Elimina multipli di 2 da L1 e li inserisce in testa a L2.
	printf("\nLista 1 modificata: \n");
	printList(L1);
	printf("\nLista 2 modificata: \n");
     
	L2 = removeNodeList1toList2(L2,L1,temp);
	printList(L2);
    
    
}


/*Questa funzione si occupa di eliminare dalla lista tutti i valori ripetuti dalla lista 1 
Prende in input L1 (che verrà anche ritornato) e una L2 che useremo come lista temporanea*/
List removeNodeRipetutiList(List L1,List L2) {
    if (L1 != NULL) { //Se la lista è piena..
          L2=L1->next;
          
        if (L1->info==scorriLista(L2,L1->info)) {  //Trovato uguale            
           
         if(L1->prev==NULL){ //Se è la testa di L1 fai...
            L1=L1->next;
            L1->prev=NULL;
	    L1 = removeNodeRipetutiList(L1,L2); }
         else if(L1->next==NULL){ //Se è ultimo elemento,allora L1= NULL;
            L1=NULL;}
         else {  //Se è elemento centrale...
            L2=L1->prev;
            L1=L1->next;
            L1->prev=L2;
            L1 = removeNodeRipetutiList(L1,L2);
             } 
			 
              }
        //Scorri successivo nella lista e ripeti... 
        if(L1!=NULL)   
        L1 -> next = removeNodeRipetutiList(L1->next,L2);  }
        
    return L1; //Ritorna testa della nuova lista.
}


/*Questa funzione si occupa di eliminare dalla lista tutti i valori ripetuti dalla lista 1 
Prende in input L1 (che verrà anche ritornato) e una L2 che useremo come lista temporanea*/
List removeNodeList1toList2(List L1,List L2,List temp) {
	  temp=L2;
    if (L1 != NULL) { //Se la lista è piena..
          
        if (L1->info==scorriLista(temp,L1->info)) {  //Trovato uguale            
           
         if(L1->prev==NULL){ //Se è la testa di L1 fai...
            L1=L1->next;
            L1->prev=NULL;
	    L1 = removeNodeList1toList2(L1,L2,temp); }
         else if(L1->next==NULL){ //Se è ultimo elemento,allora L1=NULL;
              L1=NULL;  }
          
	  else {  //Se è un elemento di mezzo...
            temp=L1->prev;
            L1=L1->next;
            L1->prev=temp;
             } 
			 
              }
        //Se non sei già alla fine scorri successivo nella lista e ripeti... 
        if(L1!=NULL)
        L1 -> next = removeNodeList1toList2(L1->next,L2,temp);  }
        
    return L1; //Ritorna testa della nuova lista.
}








