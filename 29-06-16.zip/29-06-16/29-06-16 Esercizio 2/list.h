#include <stdio.h>
#include <stdlib.h>
#include <time.h>

//Struttura che descrive la nostra lista;
struct TList {
    int info;
    struct TList* prev;
    struct TList* next;
};

typedef struct TList* List;


List initNodeList(List Prev,int info); // Inizializza un nuovo nodo

List addHeadNodeList(List L,int info);  /*Inserisce un nodo in testa alla lista*/

List appendNodeList(List L,List Prev, int info);  /* Aggiunge un nodo alla fine della lista
controllandone l'esistenza. La funzione ritorna sempre la testa della lista*/


int scorriLista(List L,int ricercato);
void freeList(List L); // Dealloca la lista interamente

void printList(List L); // Stampa la lista

int searchLista(List L,int ricercato); //Effettua una ricerca all'intero della lista;
