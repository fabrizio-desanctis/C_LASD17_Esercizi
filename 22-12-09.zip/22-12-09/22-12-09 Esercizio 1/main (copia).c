#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "stack.h"
void gioco_ric(Stack Pari,Stack Dispari,Stack temp,int turno_P,int turno_D,int minimo,int valore,int *err);//Procedura del gioco (esercizio)
void eliminaElem(Stack ST,Stack temp,int minimo,int valore, int *err); //Elimina elemento minimo nello stack.
int cercaMin(Stack ST,Stack temp,int minore,int valore, int *err); //Cerca elemento minimo;
int valoreTurnoAttuale(Stack ST,Stack temp,int Turno,int partenza,int somma,int valore,int *err); //Ritorna il valore dell'i-esimo turno.
int punteggioStack(Stack S1,int punteggio,int *err); //Calcolo del punteggio finale.
void gioco(Stack S1,Stack S2); //Funzione del gioco (esercizio).
int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));
    int err = 0;
    Stack S1 = initStack();  //Inizializza S1;
    randomStack(S1, 5, &err);  //Riempi Stack random.
    Stack S2 = initStack(); //Inizializza S2;
    randomStack(S2, 7, &err); //Riempi Stack random.
    printStack(S1, &err); //Stampa S1;
    printf("\n");
    printStack(S2,&err); //Stampa S2;
    printf("\n");
    
    gioco(S1,S2); //Esercizio
    
    
    

    return 0;
}

/*Questa funzione prende in input ST e uno stack temporaneo S2. Inoltre il valore di "Turno" serve ad indicare quanti elementi dobbiamo scorrere partendo da un valore di "partenza".La funzione estra un elemento e se è l'elemento a posizione "Turno" lo ritorna altrimenti continua a scorrere.*/
int ValoreTurnoAttuale(Stack ST,Stack temp,int Turno,int partenza,int somma,int valore,int *err){
	if(emptyStack(ST)==1){  //ST è vuoto...
          reverseStack(temp,ST,err); //Riversa temp in ST..
	  return somma; } //..e ritorna il valore.
	else {  //ST ha ancora elementi...
               valore=pop(ST,err); //...estrai in testa
               if(partenza==Turno) //...valore trovato...
                  somma=valore; //...allora salvalo in questa variabile.
                push(temp,valore,err); //...rimettilo in testa ad temp.
                somma=ValoreTurnoAttuale(ST,temp,Turno,partenza+1,somma,valore,err); //richiama la funzione
         
}	

}	

/*Questa funzione server a cercare il valore minimo di uno Stack,aiutandoci con uno stack temporaneo. */
int cercaMin(Stack ST,Stack temp,int minore,int valore, int *err){
   if(emptyStack(ST)==1) {//ST è vuoto...
          reverseStack(temp,ST,err); //Riversa temp in ST.
	  return minore;}
	  
	else {
               valore=pop(ST,err); //...estrai da ST.
	       if(valore<minore || minore==-1) //...se è primo oppure abbiamo trovato un nuovo minore.
		 minore=valore; //..assegna nuovo minore.
               push(temp,valore,err); //reinseriscilo in testa a temp.
	       
                
  minore=cercaMin(ST,temp,minore,valore,err); //Richiama la procedura.
        
}	

}

/*Questa procedura ci è utile per calcolare il punteggio dello stack in base a quanti elementi sono rimasti in esso.*/
int punteggioStack(Stack S1,int punteggio,int *err){
	if(emptyStack(S1)==1) //Stack vuoto...
          return punteggio;  //...ritorna punteggio.
	else {
               pop(S1,err); //togli elementi
               punteggio=punteggioStack(S1,punteggio+1,err); //incrementa punteggio e richiama funzione.
               
        
}	

}	


/*Questa procedura contiene tutte le utility per richiamare la vera procedura che eseguirà il gioco sugli Stack*/
void gioco(Stack Pari,Stack Dispari){
        int err = 0;
        int punteggio_Pari,punteggio_Dispari; //variabili che conterranno i punteggi.
	Stack temp = initStack(); //inizializza stack temporaneo utilizzato per l'eliminazione e la somma.
        gioco_ric(Pari,Dispari,temp,1,1,0,0,&err); //funzione che si occupa di eseguire il gioco.
        printf("\n");
	printStack(Pari, &err); //stampa nuovo S1.
        printf("\n");
        printStack(Dispari,&err); //stampa nuovo S2.
        printf("\n");  
	punteggio_Pari=punteggioStack(Pari,0,&err); //Calcola punteggio S1.
	punteggio_Dispari=punteggioStack(Dispari,0,&err); //Calcola punteggio S2.
        if(punteggio_Pari>punteggio_Dispari) //Stampa punteggi e vincitore.
	 printf("\nVince Pari");
        else if(punteggio_Pari<punteggio_Dispari)
	 printf("\nVince Dispari");
        else
 	 printf("\nPareggio");

printf("\n");



}


void eliminaElem(Stack ST,Stack temp,int minimo,int valore, int *err){
   if(emptyStack(ST)==1) //ST è vuoto...
          reverseStack(temp,ST,err); //Riversa temp in ST.
	  
	else {
               valore=pop(ST,err); //...estrai da ST.
               if(minimo!=valore) //...se non è l'elemento "minimo"
                  push(temp,valore,err); //...reinseriscilo in temp
                
  eliminaElem(ST,temp,minimo,valore,err); //Richiama la procedura.
        
}	

}



/*Questa procedura si occupa di eseguire il vero gioco richiesto nell'esercizio. Prende in input i due stack più uno temporaneo.
Per i primi due stack avremo delle variabili che indicheranno il turno cioè fino a quale posizione bisogna sommare che verranno incrementati di +1 ad ogni passaggio. Questa due variabili cammineranno di pari passo finchè uno dei due stack non arriva all'ultimo elemento,in questo caso per quello stack il turno sarà ripetuto fino alla fine del gioco. Il gioco termina se almeno uno dei due stack è vuoto*/
void gioco_ric(Stack Pari,Stack Dispari,Stack temp,int turno_P,int turno_D,int minimo,int valore,int *err){
if(emptyStack(Pari)!=1 && emptyStack(Dispari)!=1) { //Condizione per giocare...
  valore=ValoreTurnoAttuale(Pari,temp,turno_P,1,0,0,err)+ValoreTurnoAttuale(Dispari,temp,turno_D,1,0,0,err);
  if(valore%2==0){ //Se vince Pari...
	 
         minimo=cercaMin(Dispari,temp,-1,0,err);
	 eliminaElem(Dispari,temp,minimo,0,err); }
  else //Se vince Dispari..
         {
	   minimo=cercaMin(Pari,temp,-1,0,err);
	   eliminaElem(Pari,temp,minimo,0,err); } //Elimina "i-esimo" da S2.
        
	if(turno_P<Pari->A[0]) //Se possiamo scorrere ancora S1...
          turno_P=turno_P+1; //incrementa il turno altrimenti sarà ripetuto lo stesso.
	else turno_P=Pari->A[0];
        if(turno_D<Dispari->A[0]) //Se possiamo scorrere ancora S2..
          turno_D=turno_D+1;//incrementa il turno altrimenti sarà ripetuto lo stesso.
	else turno_D=Dispari->A[0];


gioco_ric(Pari,Dispari,temp,turno_P,turno_D,-1,valore,err); //Richiama il gioco al prossimo turno.
}

}
