#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "stack.h"
void gioco(Stack S1,Stack S2);
int  vincitore(Stack S1,Stack S2);
void gioco_ric(Stack S1,Stack S2,Stack temp,int turno_S1,int turno_S2,int valore,int *err);
int cercaValore(Stack S1,Stack temp,int valore,int candidato,int turno,int posizione,int *err);
void eliminaValore(Stack S1,Stack temp,int valore,int turno,int posizione,int *err);
int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));
    int err = 0;
    Stack S1 = initStack();  //Inizializza S1;
    randomStack(S1, 5, &err);  //Riempi Stack random.
    Stack S2 = initStack(); //Inizializza S2;
    randomStack(S2, 5, &err); //Riempi Stack random.
    printStack(S1, &err); //Stampa S1;
    printf("\n");
    printStack(S2,&err); //Stampa S2;
    printf("\n");
    
    gioco(S1,S2); //Esercizio
    printStack(S1, &err); //Stampa S1;
    printf("\n");
    printStack(S2,&err); //Stampa S2;
    printf("\n");
    
    

    return 0;
}


void gioco(Stack S1,Stack S2){
 
	
        if(vincitore(S1,S2)==0){
             Stack temp=initStack();
             int err=0;
             gioco_ric(S1,S2,temp,0,0,0,&err);
             if(vincitore(S1,S2)==0)
              printf("\nPAREGGIO!\n");}
}

int  vincitore(Stack S1,Stack S2){
	if(S1->A[0]>S2->A[0]){
           printf("\nVINCE S1!\n");
           return 1; }
	else if(S1->A[0]<S2->A[0]){
	   printf("\nVINCE S2!\n");
           return 1;}
       else return 0;
}


void gioco_ric(Stack S1,Stack S2,Stack temp,int turno_S1,int turno_S2,int valore,int *err){

	if( (emptyStack(S1)!=1 && emptyStack(S2)!=1) && (turno_S1<S1->A[0] && turno_S2<S2->A[0])){
		valore=cercaValore(S1,temp,0,0,turno_S1,0,err)+cercaValore(S2,temp,0,0,turno_S2,0,err);
                if(valore%2==0){
                   eliminaValore(S2,temp,0,turno_S2,0,err);
                   turno_S1=turno_S1+1; }
                else {
                   eliminaValore(S1,temp,0,turno_S1,0,err);
                   turno_S2=turno_S2+1; }
	gioco_ric(S1,S2,temp,turno_S1,turno_S2,valore,err); }

}
 
 	    


int cercaValore(Stack S1,Stack temp,int valore,int candidato,int turno,int posizione,int *err){

	if(emptyStack(S1)==1){
	  reverseStack(temp,S1,err);
          return candidato; }
        else{
            valore=pop(S1,err);
            if(posizione==turno)
              candidato=valore;
            push(temp,valore,err);
            candidato=cercaValore(S1,temp,valore,candidato,turno,posizione+1,err); }

}


void eliminaValore(Stack S1,Stack temp,int valore,int turno,int posizione,int *err){

	if(emptyStack(S1)==1){
           reverseStack(temp,S1,err); }
        else{
	   valore=pop(S1,err);
           if(posizione!=turno)
              push(temp,valore,err);
           eliminaValore(S1,temp,valore,turno,posizione+1,err); }
}

