#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "list.h"
void swap(List L1,List L2);
List removeNodeNegativiList(List L1,List L2);
List insert(List L1,List L2);
List cercaX(List L1,List L2,int x);
int main(){
        srand((unsigned int)time(NULL));
	int i=0,valore=0;
        List L1=NULL,L2=NULL; //Dichiarazione delle due liste.
        printf("\nLISTA 1\n");
        //Ciclo che inserisce 5 (ma è possibile cambiare numero) elementi casuali in L1;
	for (i=0;i<5;i++){
                printf("\nInserire valore: ");
                scanf("%d",&valore);
                printf("\n");
		L1 = appendNodeList(L1,NULL,valore); } //Appende nodo e ritorna nuova L1;

                printf("\nLISTA 2\n");  
                for (i=0;i<5;i++){
                printf("\nInserire valore: ");
                scanf("%d",&valore);
                printf("\n");
		L2 = appendNodeList(L2,NULL,valore); } //Appende nodo e ritorna nuova L1;
         
	 
        printList(L1);  //Stampa a video di L1;
        printf("\n");
        printList(L2);  //Stampa a video di L1;
        
        printf("\n\n");
      
        swap(L1,L2); //Passiamo le liste con la & per permetterne la modifica.
        printf("\n");
      
        freeList(L1);
        
        
	return 0;
}

/*Procedura che contiene le routine per eliminare tutti i multpli di 2 da L1 ed inserli in testa a L2.
  Poi elimina da L2 tutti i multipli di 5 e li inserisce in testa ad L1. Praticamente il cuore dell'esercizio
  Prende in input i puntatori alle due liste.*/
void swap(List L1,List L2){
     List temp;
     int elemento;
     
	L1=removeNodeNegativiList(L1,temp); 
        printf("\n");
	printf("\nLista 1 modificata: \n");
	printList(L1);
	printf("\n");
        L2=removeNodeNegativiList(L2,temp); 
        printf("\n");
	printf("\nLista 2 modificata: \n");
	printList(L2);
	printf("\n");

        printf("\n\nInserire valore: ");
        scanf("%d",&elemento);
        cercaX(L1,L2,elemento);
        printf("\n");
	printf("\nLista 1 modificata: \n");
	printList(L1);
	printf("\n");

    
    
}


/*Questa funzione si occupa di eliminare dalla lista tutti i valori ripetuti dalla lista 1 
Prende in input L1 (che verrà anche ritornato) e una L2 che useremo come lista temporanea*/
List removeNodeNegativiList(List L1,List L2) {
    if (L1 != NULL) { //Se la lista è piena..
          L2=L1->next;
          
        if (L1->info<0) {  //Trovato negativo            
           
         if(L1->prev==NULL){ //Se è la testa di L1 fai...
            L1=L1->next;
            L1->prev=NULL;
	    L1 = removeNodeNegativiList(L1,L2); }
         else if(L1->next==NULL){ //Se è ultimo elemento,allora L1= NULL;
            L1=NULL;}
         else {  //Se è elemento centrale...
            L2=L1->prev;
            L1=L1->next;
            L1->prev=L2;
            L1 = removeNodeNegativiList(L1,L2);
             } 
			 
              }
        //Scorri successivo nella lista e ripeti... 
        if(L1!=NULL)   
        L1 -> next = removeNodeNegativiList(L1->next,L2);  }
        
    return L1; //Ritorna testa della nuova lista.
}

List insert(List L1,List L2){
	if(L2!=NULL){
         L1=addHeadNodeList(L1,L2->info);
         L1=insert(L1,L2->next);}
return L1; }

List cercaX(List L1,List L2,int x){

	if(L1!=NULL) {
          if(L1->info==x)
            L1=insert(L1,L2);
          else L1->next=cercaX(L1->next,L2,x); }
        else L1=insert(L1,L2);

return L1;
}







