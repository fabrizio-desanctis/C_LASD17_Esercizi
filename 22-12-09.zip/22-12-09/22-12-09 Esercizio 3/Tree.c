#include <stdio.h>
#include <stdlib.h>
#include "Tree.h"



Tree initNode(int info_1,int info_2) {
    Tree T = malloc(sizeof(struct TTree));
    T->info_1 = info_1;
    T->info_2 = info_2;
    T->sx = NULL;
    T->dx = NULL;
    return T;
}

Tree insertNodeTree(Tree T, int info_1,int info_2) {
    if (T == NULL) {
        T = initNode(info_1,info_2);
    } else {
        if (T->info_1>=info_1) {
            T->sx = insertNodeTree(T->sx,info_1,info_2);
        } else if (T->info_1<info_1) {
            T->dx = insertNodeTree(T->dx, info_1,info_2);
        }
    }
    return T;
}


void inOrder(Tree T) {
    if (T != NULL) {
        inOrder(T->sx);
        printf("[%d : %d]  ", T->info_1,T->info_2);
        inOrder(T->dx);
    }
}


