#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "Tree.h"






int check_abr (Tree T, int check);
int search_abr(Tree T, int x1, int x2);

int main(int argc, const char * argv[]) {
	
	printf("Inserire albero 1\n\n");
	Tree T1=NULL;
	int val1=0,val2=0;
	for (int i=0;i<5;i++){
		printf("Inserire valore 1: ");
		scanf("%d",&val1);
                printf("Inserire valore 2: ");
		scanf("%d",&val2);
		T1 = insertNodeTree(T1, val1,val2);
	}
	
	printf("\n Albero  e': \n");

	inOrder(T1);

	int check;
	check=check_abr(T1,1);
	if(check==0)
		printf("\nAlbero non ABR");
	else 
		printf("\nAlbero ABR");

	
        printf("\n\nInserire x1: ");
        scanf("%d",&val1);
        printf("Inserire x2: ");
	scanf("%d",&val2);
        if(search_abr(T1,val1,val2)==0)
            printf("\nCOPPIA TROVATA!\n");
        else printf("\nCOPPIA NON TROVATA!\n");
	

    return 0;


}



int check_abr (Tree T, int check){ // Funzione che controlla se albero dato in input e' ABR 
	if (T!= NULL){
		if(T->sx!=NULL && T->dx != NULL){
			if((T->info_1+T->info_2) < (T->sx->info_1+T->sx->info_2) || (T->info_1+T->info_2) > (T->dx->info_1+T->dx->info_2))
				check=0;}
		else if (T->sx!=NULL && T->dx==NULL){ 
			if((T->info_1+T->info_2) < (T->sx->info_1+T->sx->info_2))
				check=0;;}
		else if (T->sx==NULL && T->dx!=NULL){
			if((T->info_1+T->info_2) > (T->dx->info_1+T->dx->info_2))
				check=0;}
		check=check_abr(T->sx,check) && check_abr(T->dx,check); 
		
	}	return check; 
}



int search_abr(Tree T, int x1, int x2){
    int check=1;
	if(T!=NULL){
          if(T->info_1==x1 && T->info_2==x2)
            check=0;
          else if(T->info_1+T->info_2 > x1+x2)
                check=search_abr(T->sx, x1, x2);
         else   check=search_abr(T->dx, x1, x2); }

return check;
}










