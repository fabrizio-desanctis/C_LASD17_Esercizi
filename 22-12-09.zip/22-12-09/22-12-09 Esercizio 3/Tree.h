#ifndef ABR_Tree_h
#define ABR_Tree_h

struct TTree {
    int info_1;
    int info_2;
    struct TTree* sx;
    struct TTree* dx;
};

typedef struct TTree* Tree;

// Inserisce un nodo nell'albero BST
Tree insertNodeTree(Tree T, int info_1,int info_2) ;

// Inizializza un nuovo nodo
Tree initNode(int info_1,int info_2);



// Esegue una visita In Order sull'albero T
void inOrder(Tree T);



#endif
