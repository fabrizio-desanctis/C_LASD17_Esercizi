#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "stack.h"
void gioco(Stack S1);

void gioco_ric(Stack S1,Stack temp,int turno_S1,int *err);
void cercaValore(Stack S1,Stack temp,int valore_prec,int valore_att,int turno,int posizione,int *err);

int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));
    int err = 0;
    Stack S1 = initStack();  //Inizializza S1;
    randomStack(S1, 5, &err);  //Riempi Stack random.
    
    printStack(S1, &err); //Stampa S1;
    printf("\n");
    
    
    gioco(S1); //Esercizio
    printStack(S1, &err); //Stampa S1;
    printf("\n");
    
    

    return 0;
}


void gioco(Stack S1){
 
	
       
             Stack temp=initStack();
             int err=0;
             gioco_ric(S1,temp,0,&err);
           
}




void gioco_ric(Stack S1,Stack temp,int turno_S1,int *err){

	if(turno_S1<S1->A[0]){
	cercaValore(S1,temp,0,0,turno_S1,0,err);
               
	gioco_ric(S1,temp,turno_S1+1,err); }

}
 
 	    


void cercaValore(Stack S1,Stack temp,int valore_prec,int valore_att,int turno,int posizione,int *err){

	if(emptyStack(S1)==1){
	  reverseStack(temp,S1,err);}
        else{
            valore_prec=pop(S1,err);
            if(posizione==turno-1){
              valore_att=pop(S1,err);
              valore_att=valore_att*valore_prec;
              push(temp,valore_prec,err);
              push(temp,valore_att,err); }

              else  push(temp,valore_prec,err);
            cercaValore(S1,temp,valore_prec,valore_att,turno,posizione+1,err); }

}




