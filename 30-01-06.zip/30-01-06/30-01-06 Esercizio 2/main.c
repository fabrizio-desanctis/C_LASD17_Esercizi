#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "list.h"
void swap(List L1,List L2);
int contaElem(List L1,int numero);
List removeNodeRipetutiList(List L1,List L2,int numero,int *flag);
List removeNodeList1toList2(List L1,List L2,List temp);
List interleading(List L1,List L2,int x);
int main(){
        srand((unsigned int)time(NULL));
	int i=0;
        List L1=NULL,L2=NULL; //Dichiarazione delle due liste.
        
        //Ciclo che inserisce 5 (ma è possibile cambiare numero) elementi casuali in L1;
	for (i=0;i<7;i++)
		L1 = appendNodeList(L1,NULL,rand() % 8); //Appende nodo e ritorna nuova L1;
         
	 //Ciclo che inserisce 5 (ma è possibile cambiare numero) elementi casuali in L2;
        for(i=0;i<7;i++)
             L2 = appendNodeList(L2,NULL,rand() % 8); //Appende nodo e ritorna nuova L2;
             
        printList(L1);  //Stampa a video di L1;
        printf("\n");
        printList(L2);
        printf("\n\n");
        
        L1=interleading(L1,L2,0);
        //swap(L1,L2); //Passiamo le liste con la & per permetterne la modifica.
        printf("\n");
        printList(L1);  //Stampa a video di L1;
        printf("\n");
        freeList(L1);
        freeList(L2);
        
        
	return 0;
}

List interleading(List L1,List L2,int x){

	if(L2!=NULL) {
          if(x==1){
             L1=addHeadNodeList(L1,L2->info);
             L1->next=interleading(L1->next,L2->next,0); }
          else {   L1->next=interleading(L1->next,L2,1); } }

else return L1;

}


/*Procedura che contiene le routine per eliminare tutti i multpli di 2 da L1 ed inserli in testa a L2.
  Poi elimina da L2 tutti i multipli di 5 e li inserisce in testa ad L1. Praticamente il cuore dell'esercizio
  Prende in input i puntatori alle due liste.*/
void swap(List L1,List L2){
     List temp;
     int flag;
     int numero_L1=0,numero_L2=0,turno=1;
        
        do{  flag=0;
        if(turno%2==1){
        numero_L1=contaElem(L1,0);
	printf("\n Cerco %d in L2", numero_L1);
	L2=removeNodeRipetutiList(L2,temp,numero_L1,&flag); //Elimina multipli di 2 da L1 e li inserisce in testa a L2. 
        turno++;
        }
        else {  numero_L2=contaElem(L2,0);
                printf("\n Cerco %d in L1", numero_L2);
	L1=removeNodeRipetutiList(L1,temp,numero_L2,&flag);
        turno++; }
        printf("\n");
        printf("\nLista 1 modificata: \n");
	printList(L1);
        printf("\nLista 2 modificata: \n");
        printList(L2);
         
        }while(L1!=NULL && L2!=NULL && flag==1);
        
	
    
    
}



int contaElem(List L1,int numero){

if(L1!=NULL){
   numero=numero+1;
   contaElem(L1->next,numero); }
else return numero;
}



/*Questa funzione si occupa di eliminare dalla lista tutti i valori ripetuti dalla lista 1 
Prende in input L1 (che verrà anche ritornato) e una L2 che useremo come lista temporanea*/
List removeNodeRipetutiList(List L1,List L2,int numero,int *flag) {
    if (L1 != NULL) { //Se la lista è piena..
          //L2=L1->next;
          
        if (L1->info==numero) {  //Trovato uguale            
           (*flag)=1;
         if(L1->prev==NULL){ //Se è la testa di L1 fai...
            L1=L1->next;
            L1->prev=NULL;
			L1 = removeNodeRipetutiList(L1,L2,numero,flag); }
         else if(L1->next==NULL){ //Se è ultimo elemento,allora L1= NULL;
            L1=NULL;}
         else {  //Se è elemento centrale...
            L2=L1->prev;
            L1=L1->next;
            L1->prev=L2;
             } 
			 
              }
        //Scorri successivo nella lista e ripeti... 
        if(L1!=NULL)   
        L1 -> next = removeNodeRipetutiList(L1->next,L2,numero,flag);  }
        
    return L1; //Ritorna testa della nuova lista.
}


/*Questa funzione si occupa di eliminare dalla lista tutti i valori ripetuti dalla lista 1 
Prende in input L1 (che verrà anche ritornato) e una L2 che useremo come lista temporanea*/
List removeNodeList1toList2(List L1,List L2,List temp) {
	  temp=L2;
    if (L1 != NULL) { //Se la lista è piena..
          
        if (L1->info==scorriLista(temp,L1->info)) {  //Trovato uguale            
           
         if(L1->prev==NULL){ //Se è la testa di L1 fai...
            L1=L1->next;
            L1->prev=NULL;
	    L1 = removeNodeList1toList2(L1,L2,temp); }
         else if(L1->next==NULL){ //Se è ultimo elemento,allora L1=NULL;
              L1=NULL;  }
          
	  else {  //Se è un elemento di mezzo...
            temp=L1->prev;
            L1=L1->next;
            L1->prev=temp;
            L1 = removeNodeList1toList2(L1,L2,temp);
             } 
			 
              }
        //Se non sei già alla fine scorri successivo nella lista e ripeti... 
        if(L1!=NULL)
        L1 -> next = removeNodeList1toList2(L1->next,L2,temp);  }
        
    return L1; //Ritorna testa della nuova lista.
}








