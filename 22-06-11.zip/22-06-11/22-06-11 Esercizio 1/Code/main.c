#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "queue.h"
void moltiplica_2(Queue Q,int indice,int *err);
void checkDispari(Queue Q,int indice,int partenza,int valore,int flag,int *err);
void moltiplica2(Queue Q);
int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));

    // Inizializzo una variabile nel main di errore
    int err = 0;

    // Inizializzo una coda
    Queue coda = initQueue();

    // Creo una coda random di 10 elementi
    randQueue(coda, 7, &err);

    // Stampo la coda
    printQueue(coda, &err);

    printf("\n");

    moltiplica2(coda);


    return 0;
}


void moltiplica2(Queue Q){

int indice=Q->A[QUEUE_MAX]-1;
int err=0;
moltiplica_2(Q,indice,&err);
printf("\n");
printQueue(Q,&err);
printf("\n");
}



void checkDispari(Queue Q,int indice,int partenza,int valore,int flag,int *err){

	if(partenza!=flag){
		valore=dequeue(Q,err);
                if(partenza!=indice) {
                   enqueue(Q,valore,err);}
		else if(valore%2==0){
                   enqueue(Q,valore,err);}
                else {
                        int successivo=dequeue(Q,err);
                        if(successivo%2==0){
                           enqueue(Q,valore,err);
			   enqueue(Q,successivo,err);
                           partenza=partenza-1;  }
                        else { 
                              enqueue(Q,(valore*successivo*2),err);
                              flag=1; } }
	checkDispari(Q,indice,partenza-1,valore,flag,err); }

}




void moltiplica_2(Queue Q,int indice,int *err){

	if(indice!=1) {
           checkDispari(Q,indice,Q->A[QUEUE_MAX]-1,0,0,err);
           moltiplica_2(Q,indice-1,err); }

}
