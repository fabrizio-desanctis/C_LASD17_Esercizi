#include "list.h"

/*Questa funzione si occupa di inizializzare un nuovo nodo della lista. Prende in input le informazioni necessarie e restituisce una nuova
occorrenza della lista.*/
List initNodeList(List Prev,int info) {
    List L = (List)malloc(sizeof(struct TList));
    L->info = info;
    L->prev = Prev;
    L->next = NULL;
    return L;
}



/*Questa funzione si occupa di appendere un nodo direttamente alla fine della lista;
Ritorna la nuova lista. */
List appendNodeList(List L,List Prev, int info) {
    if (L != NULL) {
        L->next = appendNodeList(L->next,L,info);
    } else {
        L = initNodeList(Prev,info);
    }
    return L;
}

/*Questa funzione si occupa di aggiungere un nodo direttamente in testa alla lista;*/
List addHeadNodeList(List L,int info){
	List tmp=(List)malloc(sizeof(struct TList));
	tmp->info=info;
	tmp->next=L;
	if(L!=NULL)
	   L->prev=tmp;
	
	return tmp;
}

/*Questa procedura si occupa di stampare a video tutti i valori info dei nodi di una lista*/
void printList(List L) {
    if (L != NULL) {
        if(L->prev==NULL)
        printf("%d -> ", L->info);
        else if(L->next==NULL) 
        printf("%d ",L->info);
        else  printf("%d <--> ", L->info);
        printList(L->next);
    }
} 






int scorriLista(List L,int ricercato){
	if (L != NULL) {
		if(L->info==ricercato){
		  
		  return ricercato;}
        else
         ricercato= scorriLista(L->next,ricercato);
    }
    else return -1;
    
}

/*Questa funzione si occupa di ricercare un elemento all'interno della lista. Torna 1 se trova almeno un'occorenza di ricercato,altrimenti 0*/
int searchLista(List L,int ricercato){
	if (L != NULL) {
		if(L->info==ricercato)
		  return 1;
        else
        printList(L->next);
    }
    return 0;
}

/*Questa procedura libera tutta la memoria occupata dalla lista*/
void freeList(List L) {
    if (L != NULL) {
        freeList(L->next);
        free(L);
    }
}


 

