#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "list.h"
void swap(List *L1,List *L2);
List removeNodeList1ToList2(List L1,List *L2);
List removeNodeDispariList(List L1,List L2);
int main(){
        srand((unsigned int)time(NULL));
	int i=0;
        List L1=NULL,L2=NULL; //Dichiarazione delle due liste.
        
        //Ciclo che inserisce 5 (ma è possibile cambiare numero) elementi casuali in L1;
	for (i=0;i<7;i++)
		L1 = appendNodeList(L1,NULL,rand() % 25); //Appende nodo e ritorna nuova L1;
         
	 //Ciclo che inserisce 7 (ma è possibile cambiare numero) elementi casuali in L2;
        for(i=0;i<7;i++)
             L2 = appendNodeList(L2,NULL,rand() % 25); //Appende nodo e ritorna nuova L2;
             
        printList(L1);  //Stampa a video di L1;
        printf("\n");
        printList(L2);
        printf("\n\n");
      
        swap(&L1,&L2); //Passiamo le liste con la & per permetterne la modifica.
        printf("\n");
      
        freeList(L1);
        freeList(L2);
        
	return 0;
}


void swap(List *L1,List *L2){
   List temp=NULL;
	(*L1)=removeNodeList1ToList2(*L1,L2); //Elimina pari e multipli di 3 dalla lista e li inserisce in L2 in testa.
        (*L2)=removeNodeDispariList(*L2,temp); //Elimina dispari dalla lista.
    printList(*L1); //Stampa nuova L1;
    printf("\n");
    printList(*L2); //Stampa nuova L2;
    printf("\n");	
}


/*Questa funzione si occupa di eliminare dalla lista tutti i valori dispari.*/
List removeNodeDispariList(List L1,List L2) {
    if (L1 != NULL) { //Se la lista è piena..
          //L2=L1->next;
          
        if (L1->info%2==1) {  //Trovato dispari            
           
         if(L1->prev==NULL){ //Se è la testa di L1 fai...
            L1=L1->next;
            L1->prev=NULL;
	    L1 = removeNodeDispariList(L1,L2); } 
         else if(L1->next==NULL){ //Se è ultimo elemento,allora L1= NULL;
            L1=NULL;}
         else {  //Se è elemento centrale...
            L2=L1->prev;
            L1=L1->next;
            L1->prev=L2;
            L1 = removeNodeDispariList(L1,L2);
             } 
			 
              }
        //Scorri successivo nella lista e ripeti... 
        if(L1!=NULL)   
        L1 -> next = removeNodeDispariList(L1->next,L2);  }
        
    return L1; //Ritorna testa della nuova lista.
}


/*Questa funzione si occupa di eliminare dalla lista tutti i valori pari e se sono anche multipli di 3 li elimina e li inserisce in testa a L2.*/
List removeNodeList1ToList2(List L1,List *L2) {
    if (L1 != NULL) { //Se la lista è piena..
       if (L1->info%2==0 || L1->info%3==0) {  //Trovato pari o multiplo di 3,allora...
         if(L1->info%3==0) //Se è multiplo di tre...
           (*L2)=addHeadNodeList((*L2),L1->info); //Aggiungilo in testa ad L2.
         if(L1->prev==NULL){ //Se è la testa di L1 fai...
            L1=L1->next;
            L1->prev=NULL;
	    L1 = removeNodeList1ToList2(L1,L2); } //Quindi ricontrolla la nuova testa }
         else if(L1->next==NULL){ //Se è ultimo elemento,allora L1=NULL.
            L1=NULL;}
         else {  //Se è un elemento centrale...
            List temp1=L1->prev;
            L1=L1->next;
            L1->prev=temp1;
            L1 = removeNodeList1ToList2(L1,L2);
             }    
              }
        //Scorri successivo nella lista e ripeti...
        if(L1!=NULL)
        L1->next = removeNodeList1ToList2(L1->next,L2);  }
    
    return L1; //Ritorna testa della nuova lista.
}








