#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "Tree.h"
//Struttura albero con tre nodi.

void check_abr(Tree T,int *check);
void stessaStruttura(Tree T1,Tree T2,int *flag);
int  differenza(Tree T1,Tree T2,int n);
int abs_int(int a,int b);
int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));
    
    
    Tree T1 = NULL;  //Creo T1;
    Tree T2 = NULL;  //Creo T2;
    
    int val,i;
    int check=0,flag=0;
    printf("\nCREA ALBERO 1: \n");
    for(i=0;i<5;i++){ //Creo e leggo 5 elementi
	printf("Valore %d: ",i);
	scanf("%d",&val);
	T1=insertNodeTree(T1,val); //Inserisco l'elemento i-esimo nell'ABR.
	printf("\n"); }
    printf("\nCREA ALBERO 1: \n");
    for(i=0;i<5;i++){ //Creo e leggo 5 elementi
	printf("Valore %d: ",i);
	scanf("%d",&val);
	T2=insertNodeTree(T2,val); //Inserisco l'elemento i-esimo nell'ABR.
	printf("\n"); }
    
    


    inOrder(T1); //Stampo T1;
    printf("\n"); 
    inOrder(T2);  //Stampo T2;
    printf("\n");
    check_abr(T1,&check);
   if(check==0)
     printf("\nT1 e' un ABR,");
   else  printf("\nT1 non e' un ABR,");
   check=0;
   check_abr(T1,&check);
   if(check==0)
     printf("\nT2 e' un ABR.\n");
   else  printf("\nT2 non e' un ABR.\n");
   stessaStruttura(T1,T2,&flag);
   if(flag==0)
     printf("I due alberi hanno la stressa struttura.\n");
   else  printf("I due alberi NON hanno la stressa struttura.\n");

   int n;
   printf("Inserire un valore intero: ");
   scanf("%d",&n);
   
   if(differenza(T1,T2,n)==0)
     printf("La differenza di almeno una coppia e' maggiore di %d.\n\n",n);
   else printf("La differenza di NESSUNA coppia e' maggiore di %d.\n\n",n);
    
   
    return 0;
}

/*Questa funzione si occupa di sommare i valori agli stessi livelli(se esistono) di T1 e T2 nell'albero ternario T. Prende in input i due alberi binari e un albero ternario.
In output ritorna la radice del nuovo albero ternario.*/
void stessaStruttura(Tree T1,Tree T2,int *flag) {
    if (T1 != NULL && T2!=NULL) { //Se T1 e T2 sono pieni...
       
	   stessaStruttura(T1->sx,T2->sx,flag);
	   stessaStruttura(T1->dx,T2->dx,flag); } 
           
    else if((T1!=NULL && T2==NULL)||(T1==NULL && T2!=NULL)) //Se T1 pieno e T2 vuoto o viceversa.
	   (*flag)=1;
       
       

          }
        

int  differenza(Tree T1,Tree T2,int n){
 int check=1;
   if(T1!=NULL && T2!=NULL){
     if(abs_int(T1->info,T2->info) > n)
        return 0; 
     else  return differenza(T1->sx,T2->sx,n) && differenza(T1->dx,T2->dx,n);

}

return check;

}
	

int abs_int(int a,int b){

  if(a>=b)
    return a-b;
  else
    return b-a;
}

    
void check_abr(Tree T,int *check){
    if(T!=NULL) {
      if(T->sx!=NULL && T->dx!=NULL) {
        if(T->info<T->sx->info || T->info>=T->dx->info)
           (*check)=1;
           }
      else if(T->sx!=NULL && T->dx==NULL) {
             if(T->info<T->sx->info)
                (*check)=1;
                }
      else if(T->sx==NULL && T->dx!=NULL) {
             if(T->info>=T->dx->info)
                (*check)=1;
                }

       check_abr(T->sx,check);
       check_abr(T->dx,check);    

}  

}




