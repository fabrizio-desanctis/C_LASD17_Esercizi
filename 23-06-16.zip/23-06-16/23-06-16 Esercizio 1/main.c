#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "queue.h"
void gioco(Queue coda_uno,Queue coda_due);
void gioco_ric(Queue coda_uno,Queue coda_due,int turno,int punteggio_uno,int punteggio_due,int *err);

int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));

    // Inizializzo una variabile nel main di errore
    int err = 0;
    

    // Inizializzo una coda
    Queue coda_uno = initQueue(); 
    Queue coda_due = initQueue();

    // Creo una coda random di 10 elementi
    randQueue(coda_uno, 5, &err);
    randQueue(coda_due, 7 ,&err);

    // Stampo la coda
    printQueue(coda_uno, &err);
    printf("\n");
    printQueue(coda_due, &err);

    printf("\n");
    //Esercizio gioco
    gioco(coda_uno,coda_due);


    return 0;
}

//Funzione gioco
void gioco(Queue coda_uno,Queue coda_due){
 int turno=0,punteggio_uno=0,punteggio_due=0; //Inizializzo le variabili
 int err=0; 
 gioco_ric(coda_uno,coda_due,turno,punteggio_uno,punteggio_due,&err); //Funzione ricorsiva gioco
}



void gioco_ric(Queue coda_uno,Queue coda_due,int turno,int punteggio_uno,int punteggio_due,int *err){

if(emptyQueue(coda_uno)==1 || emptyQueue(coda_due)==1){ //Caso base: almeno una delle due è vuota
   if(emptyQueue(coda_uno)==1 && emptyQueue(coda_due)==1){ // Se entrambe sono vuote stampa punteggi
     if(punteggio_uno>punteggio_due)
       printf("\nVince CODA UNO!\n");
     else if(punteggio_due>punteggio_uno)
       printf("\nVince CODA DUE!\n");
     else  printf("\nPAREGGIO\n"); 

     printf("\nPunteggio: %d - %d \n",punteggio_uno,punteggio_due);
}
       //Se solo una è vuota,svuota quella ancora piena.                                                   

   //Se coda_uno ha ancora elementi contali e incrementa punteggio coda uno
   else if(emptyQueue(coda_uno)==0){
	dequeue(coda_uno,err);
        gioco_ric(coda_uno,coda_due,turno,punteggio_uno+1,punteggio_due,err); }
   //Se invece è  coda_due ad avere ancora elementi contali e incrementa punteggio coda due
   else if(emptyQueue(coda_due)==0){
	dequeue(coda_due,err);
        gioco_ric(coda_uno,coda_due,turno,punteggio_uno,punteggio_due+1,err);}



}
     
//Entrambe piene
else  if((dequeue(coda_uno,err)+dequeue(coda_due,err))%2==turno) //Confronto 
         gioco_ric(coda_uno,coda_due,turno+1,punteggio_uno+1,punteggio_due,err); //Incrementa punteggio coda_uno che ha vinto il confronto
          
    else  
         gioco_ric(coda_uno,coda_due,turno+1,punteggio_uno,punteggio_due+1,err); //Incrementa punteggio coda_due che ha vinto il confronto
           


}
       
