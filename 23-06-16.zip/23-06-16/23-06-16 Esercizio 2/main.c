#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "list.h"
void swap(List *L1,List *L2);
int main(){
        srand((unsigned int)time(NULL));
	int i=0;
        List L1=NULL,L2=NULL; //Dichiarazione delle due liste.
        
        //Ciclo che inserisce 5 (ma è possibile cambiare numero) elementi casuali in L1;
	for (i=0;i<5;i++)
		L1 = appendNodeList(L1,NULL,rand() % 25); //Appende nodo e ritorna nuova L1;
         
	 //Ciclo che inserisce 5 (ma è possibile cambiare numero) elementi casuali in L2;
        for(i=0;i<5;i++)
             L2 = appendNodeList(L2,NULL,rand() % 25); //Appende nodo e ritorna nuova L2;
             
        printList(L1);  //Stampa a video di L1;
        printf("\n");
        printList(L2);  //Stampa a video di L2;
        printf("\n\n");
      
        swap(&L1,&L2); //Passiamo le liste con la & per permetterne la modifica.

        freeList(L1);
        freeList(L2);
        
	return 0;
}

/*Procedura che contiene le routine per eliminare tutti i multpli di 2 da L1 ed inserli in testa a L2.
  Poi elimina da L2 tutti i multipli di 5 e li inserisce in testa ad L1. Praticamente il cuore dell'esercizio
  Prende in input i puntatori alle due liste.*/
void swap(List *L1,List *L2){

	(*L1)=removeNodeList(*L1,L2,2); //Elimina multipli di 2 da L1 e li inserisce in testa a L2.
     
	(*L2)=removeNodeList(*L2,L1,5); //Elimina multipli di 5 da L2 e li inserisce in testa a L1.
    printList(*L1); //Stampa nuova L1;
    printf("\n");
    printList(*L2); //Stampa nuova L2;
    printf("\n");	
}




