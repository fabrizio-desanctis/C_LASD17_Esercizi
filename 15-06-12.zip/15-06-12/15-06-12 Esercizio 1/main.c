#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "queue.h"

void eliminaElem (Queue Q, int indice , int partenza , int valore , int parita , int flag, int *err);
void esercizio (Queue Q ,int indice, int eliminati,int flag,int *err);
void creaQueue(Queue Q, int dim, int *err);


int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));

    // Inizializzo una variabile nel main di errore
    int err = 0;

    // Inizializzo una coda
    Queue coda = initQueue();

    // Creo una coda random di 10 elementi
    randQueue(coda, 4, &err);
    
    // Stampo la coda
    printQueue(coda, &err);


    esercizio(coda,coda->A[QUEUE_MAX]-1,0,0,&err);



    return 0;



}



void esercizio (Queue Q ,int indice, int eliminati,int flag,int *err ){
	if (indice-eliminati!=1){ // Condizione di uscita 
		if ( indice %2 == 0 ){ 
			printf("\n");
			eliminaElem(Q,indice,Q->A[QUEUE_MAX]-1,0,0,0,err); // Richiama con parità pari
			printf("\n");
			printQueue(Q, err); }
		else {
			printf("\n");
			eliminaElem(Q,indice,Q->A[QUEUE_MAX]-1,0,1,0,err); // Richiama con parità dispari
			printf("\n");
			printQueue(Q, err); }
		if (flag==1)
			esercizio(Q,indice,eliminati+1,0,err); // Un elemento eliminato
		else
			esercizio(Q,indice-1,eliminati,0,err); // Nessun elemento eliminato
	}

}
			





void eliminaElem (Queue Q, int indice , int partenza , int valore , int parita , int flag, int *err ){

	if (partenza!=flag){ // Se e' stato eliminato un elemento deve fare un confronto in meno
		
		valore=dequeue(Q,err);
		if(partenza!=indice){ // Se non e' l'elemento ricercato 
			
			enqueue(Q,valore,err);} // Mettilo in coda 
		else 
			if(valore%2!=parita) { // Se e' il ricercato ma non hanno la stessa parità 
				
				enqueue (Q,valore,err);} // Mettilo in coda 
			else {
				int successivo =dequeue(Q,err); 
				
				if ( successivo >=valore){ // Confronta con il successivo , se il successivo è maggiore 
					enqueue(Q,valore,err); // Inserisci prima l'elemento
					enqueue(Q,successivo,err); // Poi il successivo (per ripristinare il giusto ordine) 
					partenza=partenza-1; } // Avendo già fatto due spostamenti, ne servirà uno in meno
				else { 
					
					enqueue(Q,successivo,err); // Sposta soltanto il successivo, eliminando il ricercato
					flag =1;} // E' stato eliminato un elemento
				}
	eliminaElem(Q,indice,partenza-1,valore,parita,flag,err);
}

}

void creaQueue(Queue Q, int dim, int *err){
    int i = 0;
    int valore=0;
    for (i = 0; i <= dim; i++){
	printf("\nInserire valore:");
	scanf("%d", &valore); 
        enqueue(Q,valore,err);
    }
}			
		
	








			
			
		
	
		
	
		
		
		
		







