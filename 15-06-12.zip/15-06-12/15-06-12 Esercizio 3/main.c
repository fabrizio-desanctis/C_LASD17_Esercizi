#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "Tree.h"

struct TTree_Tern {
    int info;
    struct TTree_Tern* sx;
    struct TTree_Tern* dx;
    struct TTree_Tern* middle;
};

typedef struct TTree_Tern* Tree_Tern;

Tree_Tern initNode_Tern(int info);
Tree_Tern insertNodeTree_Tern(Tree_Tern T, int info);
void inOrder_Tern(Tree_Tern T);
Tree_Tern albero_ternario (Tree T1,Tree_Tern T3);
void figlio_mezzo (Tree_Tern T3);
void check_abr (Tree T, int *check);


int main(int argc, const char * argv[]) {
	
	printf("Inserire albero 1\n\n");
	Tree T1=NULL;
	int val1=0;
	for (int i=0;i<5;i++){
		printf("Inserire valore ");
		scanf("%d",&val1);
		T1 = insertNodeTree(T1, val1);
	}
	
	printf("\n Albero  e': \n");

	inOrder(T1);

	int check=0;
	check_abr(T1,&check);
	if(check==1)
		printf("\nAlbero non ABR");
	else 
		printf("\nAlbero ABR");

	
	Tree_Tern T3=NULL;
	T3=albero_ternario(T1,T3);
	printf("\nAlbero Ternario:\n");
	inOrder_Tern(T3);
	printf("\nAlbero con figlio di mezzo:\n");
	figlio_mezzo(T3);
	printf("\n\n");
	inOrder_Tern(T3);

	/*Tree_Tern T3=NULL; //Creo albero ternario
	T3=albero_ternario(T1,T2,T3);

	printf("\nAlbero Ternario e': \n");
	inOrder_Tern(T3);

	printf("\n\n");
	
	figlio_mezzo(T3);
	printf("\n\n");
	printf("Albero compreso di figli middle: \n");
	inOrder_Tern(T3); */

    return 0;


}


Tree_Tern albero_ternario (Tree T1,Tree_Tern T3){
	if(T1!=NULL){
		T3=insertNodeTree_Tern(T3,T1->info);
		T3=albero_ternario(T1->sx,T3);
		T3=albero_ternario(T1->dx,T3); } 
	return T3;
		}


void figlio_mezzo (Tree_Tern T3){
	if(T3!=NULL) {
		if(T3->sx!= NULL && T3->dx!=NULL){
			T3->middle=initNode_Tern((T3->sx->info+T3->dx->info)/2);
			printf("\n\nLa media tra %d e %d e' uguale a: %d",T3->sx->info,T3->dx->info,T3->middle->info); }
		else if (T3->sx==NULL && T3->dx!=NULL)
			T3->middle=initNode_Tern(T3->dx->info/2);
		else if (T3->dx==NULL && T3->sx!=NULL)
			T3->middle=initNode_Tern(T3->sx->info/2);
	figlio_mezzo(T3->sx);
	figlio_mezzo(T3->dx); }
	

}
			


Tree_Tern initNode_Tern(int info) {
    Tree_Tern T = malloc(sizeof(struct TTree_Tern));
    T->info = info;
    T->sx = NULL;
    T->dx = NULL;
    T->middle=NULL;
    return T;
}

Tree_Tern insertNodeTree_Tern(Tree_Tern T, int info) {
    if (T == NULL) {
        T = initNode_Tern(info);
    } else {
        if (T->info >= info) {
            T->sx = insertNodeTree_Tern(T->sx, info);
        } else if (T->info < info) {
            T->dx = insertNodeTree_Tern(T->dx, info);
        }
    }
    return T;
}

void inOrder_Tern(Tree_Tern T) {
    if (T != NULL) {
        inOrder_Tern(T->sx);
        printf("%d ", T->info);
        if(T->middle!=NULL)
        printf("[%d]",T->middle->info);
        inOrder_Tern(T->dx);
    }
}

void check_abr (Tree T, int *check){ // Funzione che controlla se albero dato in input e' ABR 
	if (T!= NULL){
		if(T->sx!=NULL && T->dx != NULL){
			if(T->info < T->sx->info || T->info > T->dx->info)
				(*check)=1;}
		else if (T->sx!=NULL && T->dx==NULL){ 
			if(T->info < T->sx->info)
				(*check)=1;;}
		else if (T->sx==NULL && T->dx!=NULL){
			if(T->info > T->dx->info)
				(*check)=1;}
		check_abr(T->sx,check);
		check_abr(T->dx,check); 
		
	}	 
}




