#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "queue.h"

void eliminaElem (Queue Q, int indice , int partenza , int valore , int parita , int flag, int *err);
void esercizio (Queue Q ,int indice, int eliminati,int flag,int *err);
void creaQueue(Queue Q, int dim, int *err);
void moltiplica2 (Queue Q, int indice,int *flag,int *err);
void checkDispari (Queue Q,int indice,int valore, int partenza , int *flag , int *err);
void moltiplica(Queue Q);


int main(int argc, const char * argv[]) {
    srand((unsigned int)time(NULL));

    // Inizializzo una variabile nel main di errore
    int err = 0;

    // Inizializzo una coda
    Queue coda = initQueue();

    // Creo una coda random di 10 elementi
    creaQueue(coda, 4, &err);
    
    // Stampo la coda
    printQueue(coda, &err);

    moltiplica(coda);





    return 0;



}

void moltiplica(Queue Q){
	int indice=Q->A[QUEUE_MAX]-1;
	int err=0;
	int flag=0;
	moltiplica2(Q,indice,&flag,&err);
}

void checkDispari (Queue Q,int indice,int valore, int partenza , int *flag , int *err){
	if(partenza!=(*flag)){
		valore=dequeue(Q,err);
		if(partenza!=indice)
			enqueue(Q,valore,err);
		else{
			int successivo1=dequeue(Q,err);
			if(*err!=6){
				int successivo2=dequeue(Q,err);
				if (*err==6){
					enqueue(Q,valore,err);
					enqueue(Q,successivo1,err);
					partenza=partenza-1;}
				else{
					enqueue(Q,(valore*successivo1*successivo2),err);
					(*flag)=2;} } // Questo parametro e' stato cambiato per permettere il corretto "riavvolgimento" della coda. (sono stati tolti 3 elementi e messo 1)
		     }
							
	checkDispari(Q,indice,valore,partenza-1,flag,err);
}
	
}




void moltiplica2 (Queue Q, int indice,int *flag,int *err){
	if(indice!=1){
		checkDispari(Q,indice,0,Q->A[QUEUE_MAX]-1,flag,err);
		printf("\n\n");
		printQueue(Q,err);
		if((*flag)==2){
			(*flag)=0;
			indice=indice-3; // Serve a far partire l'indice in checkDispari dalla giusta posizione
			if(indice>2){ // Se rimangono meno di 2 elementi alla fine della coda il programma termina
				moltiplica2(Q,indice,flag,err);} }
		else{ 
			(*flag)=0;
			indice=indice-1;
			if(indice>2)
				moltiplica2(Q,indice,flag,err);}
	}
}
			



void creaQueue(Queue Q, int dim, int *err){
    int i = 0;
    int valore=0;
    for (i = 0; i <= dim; i++){
	printf("\nInserire valore:");
	scanf("%d", &valore); 
        enqueue(Q,valore,err);
    }
}			
		
	








			
			
		
	
		
	
		
		
		
		







